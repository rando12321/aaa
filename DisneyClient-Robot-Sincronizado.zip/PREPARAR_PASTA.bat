@echo off
setlocal
call "%~dp0INICIAR_CLIENT.bat" --extract-only
if errorlevel 1 exit /b 1
echo.
echo Pasta preparada. Copie sua .env para DisneyClient-Local-Robot-Novo\DisneyClient antes de iniciar, se necessario.
pause
exit /b 0
