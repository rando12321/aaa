"""Prepare the complete bundled client using only the Python standard library."""
from __future__ import annotations

import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import tarfile
import tempfile

PAYLOAD = 'client-completo.tar.xz'
PROJECT = 'DisneyClient-Local-Robot-Novo'
STAMP = '.pacote-local.sha256'
MAX_UNPACKED = 1024 * 1024 * 1024
ESSENTIALS = (
    'INICIAR_CLIENT.bat',
    'iniciar_client.py',
    'DisneyClient/server.py',
    'DisneyClient/public/ChargeurTransformice.swf',
    'DisneyParser/main.py',
)


class PackageError(Exception):
    """An invalid bundle or an unsafe extraction destination."""


def _state(path: Path):
    try:
        return path.lstat()
    except FileNotFoundError:
        return None


def _linked(info) -> bool:
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, 'st_file_attributes', 0)
        & getattr(stat, 'FILE_ATTRIBUTE_REPARSE_POINT', 0x400)
    )


def _regular(path: Path) -> None:
    info = _state(path)
    if info is None or _linked(info) or not stat.S_ISREG(info.st_mode):
        raise PackageError(f'Arquivo ausente ou invalido: {path.name}.')


def _directory(path: Path) -> None:
    info = _state(path)
    if info is not None:
        if _linked(info) or not stat.S_ISDIR(info.st_mode):
            raise PackageError(f'Pasta de destino invalida: {path.name}.')
        return
    path.mkdir()
    info = path.lstat()
    if _linked(info) or not stat.S_ISDIR(info.st_mode):
        raise PackageError(f'Pasta de destino invalida: {path.name}.')


def _hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def _expected(base: Path) -> str:
    sidecar = base / 'SHA256.json'
    _regular(sidecar)
    if sidecar.stat().st_size > 65536:
        raise PackageError('SHA256.json excede o tamanho permitido.')
    try:
        values = json.loads(sidecar.read_text(encoding='utf-8-sig'))
    except (ValueError, UnicodeError) as error:
        raise PackageError('SHA256.json esta malformado.') from error
    value = values.get(PAYLOAD) if isinstance(values, dict) else None
    if not isinstance(value, str) or re.fullmatch(r'[0-9a-fA-F]{64}', value) is None:
        raise PackageError('SHA256.json nao contem o hash valido do pacote completo.')
    return value.lower()


def _parts(name: str) -> tuple[str, ...]:
    if not name or '\x00' in name or '\\' in name or ':' in name or name.startswith('/'):
        raise PackageError('O pacote contem um caminho de arquivo invalido.')
    # A single trailing slash is conventional for a directory entry.
    stripped = name[:-1] if name.endswith('/') else name
    parts = tuple(stripped.split('/'))
    if not parts or parts[0] != PROJECT:
        raise PackageError('O pacote nao contem a pasta esperada do client.')
    for part in parts:
        if not part or part in ('.', '..') or part.endswith((' ', '.')) or any(ord(char) < 32 or char in '<>\"|?*' for char in part):
            raise PackageError('O pacote contem um caminho de arquivo invalido.')
        stem = part.split('.')[0].upper()
        if stem in {'CON', 'PRN', 'AUX', 'NUL'} or re.fullmatch(r'(?:COM|LPT)[1-9]', stem):
            raise PackageError('O pacote contem um nome reservado pelo Windows.')
    if len(parts) == 2 and parts[1].casefold() == STAMP.casefold():
        raise PackageError('O pacote contem um marcador de instalacao reservado.')
    return parts


def _members(archive: tarfile.TarFile):
    checked = []
    seen = set()
    files = set()
    total = 0
    for member in archive.getmembers():
        parts = _parts(member.name)
        key = tuple(part.casefold() for part in parts)
        if key in seen:
            raise PackageError('O pacote contem nomes duplicados ou ambiguos.')
        seen.add(key)
        if member.type == tarfile.DIRTYPE:
            kind = 'directory'
        elif member.type in (tarfile.REGTYPE, tarfile.AREGTYPE):
            if len(parts) == 1 or member.size < 0:
                raise PackageError('O pacote contem um arquivo invalido.')
            total += member.size
            if total > MAX_UNPACKED:
                raise PackageError('O pacote descompactado excede o limite permitido.')
            files.add(key)
            kind = 'file'
        else:
            raise PackageError('O pacote deve conter apenas arquivos e pastas comuns.')
        checked.append((member, parts, kind))
    if not checked:
        raise PackageError('O pacote completo esta vazio.')
    for _, parts, _ in checked:
        key = tuple(part.casefold() for part in parts)
        if any(key[:index] in files for index in range(1, len(key))):
            raise PackageError('O pacote contem um arquivo usado como pasta.')
    required = {
        tuple(part.casefold() for part in (PROJECT + '/' + name).split('/'))
        for name in ESSENTIALS
    }
    if not required.issubset(files):
        raise PackageError('O pacote completo esta sem arquivos essenciais do client.')
    return checked


def _destination(base: Path, parts: tuple[str, ...], directory: bool = False) -> Path:
    current = base
    parents = parts if directory else parts[:-1]
    for part in parents:
        current = current / part
        _directory(current)
    if directory:
        return current
    target = current / parts[-1]
    info = _state(target)
    if info is not None and (_linked(info) or not stat.S_ISREG(info.st_mode)):
        raise PackageError(f'Arquivo de destino invalido: {target.name}.')
    return target


def _preserve(parts: tuple[str, ...]) -> bool:
    relative = tuple(part.casefold() for part in parts[1:])
    if relative in {('disneyclient', '.env'), ('disneyclient', 'config.json')}:
        return True
    return len(relative) > 3 and relative[:3] == ('disneyclient', 'public', 'rotas')


def _replace(target: Path, source, expected_size: int | None = None) -> None:
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(prefix='.pacote-', dir=target.parent, delete=False) as output:
            temporary = Path(output.name)
            copied = 0
            for block in iter(lambda: source.read(1024 * 1024), b''):
                output.write(block)
                copied += len(block)
            if expected_size is not None and copied != expected_size:
                raise PackageError('Um arquivo do pacote esta incompleto.')
        os.replace(temporary, target)
        temporary = None
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def _installed(project: Path, digest: str) -> bool:
    info = _state(project)
    if info is None:
        return False
    if _linked(info) or not stat.S_ISDIR(info.st_mode):
        raise PackageError('A pasta do client nao e uma pasta comum.')
    marker = project / STAMP
    info = _state(marker)
    if info is None:
        return False
    _regular(marker)
    if info.st_size > 128:
        return False
    try:
        installed_hash = marker.read_text(encoding='ascii').strip()
    except UnicodeError:
        return False
    if installed_hash != digest:
        return False
    for name in ESSENTIALS:
        parts = (PROJECT, *name.split('/'))
        current = project.parent
        for part in parts:
            current = current / part
            state = _state(current)
            if state is None:
                return False
            if _linked(state):
                raise PackageError('O client instalado contem um redirecionamento de caminho.')
        _regular(current)
    return True


def prepare(base: Path) -> Path:
    base = base.resolve(strict=True)
    payload = base / PAYLOAD
    digest = _expected(base)
    _regular(payload)
    if _hash(payload) != digest:
        raise PackageError('O arquivo do pacote completo esta corrompido ou incompleto. Baixe o ZIP novamente.')
    project = base / PROJECT
    if _installed(project, digest):
        print('Client completo ja preparado.', flush=True)
        return project
    print('Preparando os arquivos do client completo...', flush=True)
    with tarfile.open(payload, mode='r:xz') as archive:
        checked = _members(archive)
        for member, parts, kind in checked:
            target = _destination(base, parts, directory=kind == 'directory')
            if kind == 'directory':
                continue
            if _state(target) is not None and _preserve(parts):
                continue
            with archive.extractfile(member) as source:
                _replace(target, source, member.size)
    # The stamp is committed only after the complete archive succeeds.
    import io
    _replace(project / STAMP, io.BytesIO((digest + '\n').encode('ascii')))
    print('Client completo preparado.', flush=True)
    return project


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description='Extrair e iniciar o client completo local.')
    parser.add_argument('--extract-only', action='store_true', help='Apenas preparar os arquivos, sem iniciar o client.')
    options = parser.parse_args(argv)
    if sys.version_info < (3, 11):
        print('Instale Python 3.11 ou superior e abra INICIAR_CLIENT.bat novamente.', file=sys.stderr)
        return 1
    if not options.extract_only and os.name != 'nt':
        print('Use --extract-only para preparar os arquivos fora do Windows.', file=sys.stderr)
        return 1
    try:
        project = prepare(Path(__file__).resolve().parent)
        if options.extract_only:
            print(str(project))
            return 0
        return subprocess.call([sys.executable, str(project / 'iniciar_client.py')], cwd=str(project))
    except KeyboardInterrupt:
        return 0
    except (PackageError, OSError, ValueError, tarfile.TarError, lzma.LZMAError, EOFError) as error:
        print('Nao foi possivel preparar o client: ' + str(error), file=sys.stderr)
        print('Extraia o ZIP inteiro na mesma pasta e tente novamente.', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
